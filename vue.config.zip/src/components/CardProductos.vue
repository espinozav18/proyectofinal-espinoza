
<template>
  <v-card hover max-height="520" min-height="520">
    <v-card-title>
      <v-img
        height="250"
        width="200px"
        :src="require('../assets/img/' + producto.imagenes[0])"
      />
      {{ producto.nombre }}
    </v-card-title>

    <v-card-text>
      <p>Precio: <strong>{{ producto.moneda }} {{ producto.precio |decimal2}}</strong></p>
      <p v-if="producto.stock > 0">Cantidad: {{ producto.stock }}</p>
      <v-chip v-else dark>Sin stock</v-chip>
    </v-card-text>
    <v-card-actions>
      <v-btn color="success" v-if="producto.stock > 0">Comprar</v-btn>
      <v-spacer></v-spacer>
      <v-btn color="info">Detalle</v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  props: {
    producto: Object,
  },
  filters:{
    decimal2(value){
      return value.toFixed(2)
    }
  }
};
</script>

<style lang="scss" scoped>
</style>