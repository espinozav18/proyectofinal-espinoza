<template>
  <v-app-bar app color="primary" dark>
    <div class="d-flex align-center">
      <v-img
        alt="Vuetify Logo"
        class="shrink mr-2"
        contain
        src="../assets/tienda.png"
        transition="scale-transition"
        width="40"
      />

      <h3>Tienda online</h3>
      <v-navigation-drawer stateless class="indigo darken-1" app>
        <v-list>
          <v-list-item v-for="(item, index) in items" :key="index" link>
            <v-list-item-icon>
              <v-icon>{{ item.title }}</v-icon>
            </v-list-item-icon>

            <v-list-item-content>
              <v-list-item-title>{{ item.title }}</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-navigation-drawer>
    </div>

    <v-spacer></v-spacer>

    <v-menu offset-y>
      <template v-slot:activator="{ on, attrs }">
        <v-btn color="primary" dark v-bind="attrs" v-on="on">
          <v-icon>mdi-account</v-icon>Usuario
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="(item, index) in items"
          :key="index"
          link
          :href="'http://google.com'"
          :target="'_blank'"
        >
          <v-list-item-title v-text="item.title"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
    <!-- <v-btn
      href="https://github.com/vuetifyjs/vuetify/releases/latest"
      target="_blank"
      text
    >
      <v-icon>mdi-account</v-icon>
      <span class="mr-2">Usuario</span>
    </v-btn>-->
  </v-app-bar>
</template>

<script>
export default {
  name: "Navbar",

  data: () => ({
    items: [{ title: "Cerrar" }],
  }),
};
</script>
